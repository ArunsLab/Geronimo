var struct_m_d___menu_1_1mnu_item__t =
[
    [ "action", "struct_m_d___menu_1_1mnu_item__t.html#a2b6728c981ac2ee691a8520493f48e2e", null ],
    [ "actionId", "struct_m_d___menu_1_1mnu_item__t.html#a4cc8d312677342df63df4d848c439cd3", null ],
    [ "id", "struct_m_d___menu_1_1mnu_item__t.html#aba8ea4e255c2f1087a446e5f7fb8189d", null ],
    [ "label", "struct_m_d___menu_1_1mnu_item__t.html#a2a3abba5f64a7b2e5a90923527104107", null ]
];