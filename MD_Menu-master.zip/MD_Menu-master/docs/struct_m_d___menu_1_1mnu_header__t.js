var struct_m_d___menu_1_1mnu_header__t =
[
    [ "id", "struct_m_d___menu_1_1mnu_header__t.html#a1322091d399dcf505bf7297705e4148b", null ],
    [ "idItmCurr", "struct_m_d___menu_1_1mnu_header__t.html#ade79baa91fc9dfc1983eb73f1596e880", null ],
    [ "idItmEnd", "struct_m_d___menu_1_1mnu_header__t.html#aa60efab8b216a30dd5dfa7c58fd9b838", null ],
    [ "idItmStart", "struct_m_d___menu_1_1mnu_header__t.html#aea40225d6bfba7a80ba261bad62bfc87", null ],
    [ "label", "struct_m_d___menu_1_1mnu_header__t.html#a21ce1d68ee920ec99178fe85becd90b4", null ]
];