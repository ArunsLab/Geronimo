var searchData=
[
  ['copyright',['Copyright',['../page_copyright.html',1,'index']]]
];
