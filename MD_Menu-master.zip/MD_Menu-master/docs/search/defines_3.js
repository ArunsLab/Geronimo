var searchData=
[
  ['inp_5fpost_5fsize',['INP_POST_SIZE',['../_m_d___menu__lib_8h.html#a595a6ab5a53443036d11232898ef1068',1,'MD_Menu_lib.h']]],
  ['inp_5fpre_5fsize',['INP_PRE_SIZE',['../_m_d___menu__lib_8h.html#ac4d67cb7944c405e97b02f203e954d25',1,'MD_Menu_lib.h']]]
];
