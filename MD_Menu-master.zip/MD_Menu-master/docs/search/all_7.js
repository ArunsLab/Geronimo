var searchData=
[
  ['header_5flabel_5fsize',['HEADER_LABEL_SIZE',['../_m_d___menu_8h.html#a047fee32ff3761bfb49b5f165f5c3bde',1,'MD_Menu.h']]]
];
