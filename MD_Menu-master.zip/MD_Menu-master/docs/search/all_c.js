var searchData=
[
  ['plist',['pList',['../struct_m_d___menu_1_1mnu_input__t.html#a639a79c5bb17792d7c2b26900d14f389',1,'MD_Menu::mnuInput_t']]],
  ['power',['power',['../struct_m_d___menu_1_1value__t.html#af741cb97cfbf5926f82886c2d8ae7194',1,'MD_Menu::value_t']]]
];
