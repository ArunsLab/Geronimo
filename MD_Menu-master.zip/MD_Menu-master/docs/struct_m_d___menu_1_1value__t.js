var struct_m_d___menu_1_1value__t =
[
    [ "power", "struct_m_d___menu_1_1value__t.html#af741cb97cfbf5926f82886c2d8ae7194", null ],
    [ "value", "struct_m_d___menu_1_1value__t.html#adc50a1e0ea0a621744cbe1a60ebd5136", null ]
];